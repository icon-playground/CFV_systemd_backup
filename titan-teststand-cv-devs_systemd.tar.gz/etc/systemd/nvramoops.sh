#!/bin/bash
# SPDX-FileCopyrightText: Copyright (c) 2022-2023 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

if [[ -e "/proc/device-tree/compatible" && -e "/proc/device-tree/model" ]]; then
    machine="$(tr -d '\0' < /proc/device-tree/compatible)"
    model="$(tr -d '\0' < /proc/device-tree/model)"

    if [[ ( "${machine}" =~ "tegra194" && "${model}" != "Jetson-AGXi" ) ||
          ( "${machine}" =~ "tegra234" ) ]]; then
            modprobe ramoops
    fi
fi