#!/bin/bash

# SPDX-FileCopyrightText: Copyright (c) 2019-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
# list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its
# contributors may be used to endorse or promote products derived from
# this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

KERNEL_CMDLINE="$(cat /proc/cmdline)"
/bin/systemctl start nv-l4t-usb-device-mode.service

if [[ -f /usr/lib/nvidia/resizefs/nvresizefs.templates ]]; then
	/usr/bin/debconf-loadtemplate nvresizefs \
		/usr/lib/nvidia/resizefs/nvresizefs.templates
fi

if [[ -f /usr/lib/nvidia/swap/nvswap.templates ]]; then
	/usr/bin/debconf-loadtemplate nvswap \
		/usr/lib/nvidia/swap/nvswap.templates
fi

if [[ -f /usr/lib/nvidia/nvpmodel/nvpmodel.templates ]]; then
	/usr/bin/debconf-loadtemplate nvpmodel \
		/usr/lib/nvidia/nvpmodel/nvpmodel.templates
fi

if [[ -f /usr/lib/nvidia/qspi-update/nvqspi-update.templates ]]; then
	/usr/bin/debconf-loadtemplate nvqspi-update \
		/usr/lib/nvidia/qspi-update/nvqspi-update.templates
fi

if [[ -f /usr/lib/nvidia/crypt-passwd/nvcrypt-passwd.templates ]]; then
        /usr/bin/debconf-loadtemplate nvcrypt-passwd \
                /usr/lib/nvidia/crypt-passwd/nvcrypt-passwd.templates
fi

if [[ -f /usr/lib/nvidia/chromium/nvchromium.templates ]]; then
	/usr/bin/debconf-loadtemplate nvchromium \
		/usr/lib/nvidia/chromium/nvchromium.templates
fi

# Wait for the process to finish which has aquired this lock
while fuser "/var/cache/debconf/config.dat" > "/dev/null" 2>&1; do sleep 1; done;
while fuser "/var/cache/debconf/templates.dat" > "/dev/null" 2>&1; do sleep 1; done;

NV_AUTO_CONFIG=false
if [[ "${KERNEL_CMDLINE}" =~ "nv-auto-config" ]] && [[ -e "/nv_preseed.cfg" ]]; then
	# check preseed file format
	if /usr/bin/debconf-set-selections -c /nv_preseed.cfg; then
		while ! /usr/bin/debconf-set-selections /nv_preseed.cfg; do sleep 1; done;

		# oem-config auto mode only supports standard ubiquity plugins,
		# so remove NV plugins before running oem-config auto mode.
		rm -f /usr/lib/ubiquity/plugins/nv*.py

		touch /etc/nv/nvautoconfig
		NV_AUTO_CONFIG=true
	fi
fi

# Start X server to query display info in order to check if any display is connected
DISPLAY_PLUGGED=false
X vt7 :0 &
if [ "$?" = "0" ]; then
	x_pid=$!
	sleep 3
	check_connected="$(DISPLAY=:0 xrandr --query | grep " connected")"
	if [ -n "${check_connected}" ]; then
		DISPLAY_PLUGGED=true
	fi
	kill ${x_pid}
fi

if [[ "${NV_AUTO_CONFIG}" = true ]] || [[ "${DISPLAY_PLUGGED}" = true ]]; then
	if [[ "${NV_AUTO_CONFIG}" = true ]]; then
		/bin/echo "<5>Please wait for auto system configuration setup to complete..." > "/dev/kmsg"
	else
		/bin/echo "<5>Please complete system configuration setup on desktop to proceed..." > "/dev/kmsg"
	fi

	# Temporarily ban source lists to avoid waiting for `apt-get update` during oem-config
	find "/etc/apt" -type f -name '*.list' -exec mv {} {}.banned \;

	/bin/systemctl start nv-oem-config-gui.service
else
	CONF_FILE="/etc/nv-oem-config.conf"

	UART_PORT="$(grep uart-port "${CONF_FILE}" | cut -d '=' -f 2)"
	if [[ -n "${UART_PORT}" ]]; then
		for i in {1..5}; do
			if [[ -e "/dev/${UART_PORT}" ]]; then
				break;
			elif [[ "${i}" =~ "5" ]]; then
				if [[ -e "/dev/ttyTCU0" ]]; then
					UART_PORT="ttyTCU0"
				elif [[ -e "/dev/ttyAMA0" ]]; then
					UART_PORT="ttyAMA0"
				elif [[ -e "/dev/ttyAMA6" ]]; then
					UART_PORT="ttyAMA6"
				elif [[ -e "/dev/ttyS0" ]]; then
					UART_PORT="ttyS0"
				else
					UART_PORT=""
				fi
			else
				sleep 1
			fi
		done
	fi

	if [[ -n "${UART_PORT}" ]]; then
		msg="<4>Please complete system configuration setup on the serial port "
		msg+="provided by Jetson's USB device mode connection. e.g. "

		if [[ "${UART_PORT}" =~ "ttyGS0" ]]; then
			msg+="/dev/ttyACMx "
		else
			msg+="/dev/ttyUSBx "
		fi

		msg+="where x can 0, 1, 2 etc."

		/bin/echo "${msg}" > "/dev/kmsg"
		/bin/stty -F /dev/${UART_PORT} 115200 cs8 -parenb -cstopb
		/bin/systemctl start nv-oem-config-debconf@${UART_PORT}.service
	else
		/bin/echo "<3>No serial port found to configure system!" > "/dev/kmsg"
	fi
fi
exit 0
