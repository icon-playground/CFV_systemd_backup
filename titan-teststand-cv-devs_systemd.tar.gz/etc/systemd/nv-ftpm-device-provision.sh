#!/bin/bash

# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
# list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its
# contributors may be used to endorse or promote products derived from
# this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

set -e

export TPM2TOOLS_TCTI="device:/dev/tpmrm0"

# Log levels
LOG_ERROR=0
LOG_INFO=1
LOG_DEBUG=2
# Default log level (show error logs only)
LOG_LEVEL=${LOG_ERROR}

# fTPM helper CA
NV_FTPM_HELPER_APP="nvftpm-helper-app"

# fTPM temp out folder
FTPM_TEMP_OUT="/var/tmp/nv_ftpm_prov_systemd"

# fTPM temp files
FTPM_EKB_RSA_EK_PUB_KEY="${FTPM_TEMP_OUT}/ekb_rsa_ek_pub_key.pem"
FTPM_EKB_EC_EK_PUB_KEY="${FTPM_TEMP_OUT}/ekb_ec_ek_pub_key.pem"
FTPM_RSA_EK_PUB_KEY="${FTPM_TEMP_OUT}/rsa_ek_pub_key.pem"
FTPM_EC_EK_PUB_KEY="${FTPM_TEMP_OUT}/ec_ek_pub_key.pem"

# TPM NV handles
RSA_EK_HANDLE="0x81010001"
EC_EK_HANDLE="0x81010002"
RSA_EK_CERT_HANDLE="0x01c00002"
EC_EK_CERT_HANDLE="0x01c0000a"

# TPM EK cert attribute
EK_CERT_ATTR="ppwrite|writedefine|ppread|ownerread|authread|no_da|platformcreate"

# Set the default certificate files and owner password
FTPM_RSA_EK_CERT="${FTPM_TEMP_OUT}/rsa_ek.cert"
FTPM_EC_EK_CERT="${FTPM_TEMP_OUT}/ec_ek.cert"
FTPM_OWNER_PW="owner"

# Add a new variable to track if we should keep certificates
KEEP_CERTS=false

SCRIPT_NAME="$(basename "${0}")"

# Logging functions
function log_error() {
    # Error logs are always shown
    echo "[fTPM device] Error: $1" >&2
}

function log_info() {
    # Show info logs if level is at least INFO
    if [ ${LOG_LEVEL} -ge ${LOG_INFO} ]; then
        echo "[fTPM device]: $1"
    fi
}

function log_debug() {
    # Show debug logs only if level is DEBUG
    if [ ${LOG_LEVEL} -ge ${LOG_DEBUG} ]; then
        echo "[fTPM device]: $1"
    fi
}

function usage {
	cat << EOM
Usage: ./${SCRIPT_NAME} [OPTIONS]

This script helps to provision fTPM via EKB.
Options:
	-r	The RSA EK certificate file name that extracts from EKB. (Default: ${FTPM_RSA_EK_CERT})
	-e	The EC EK certificate file name that extracts from EKB. (Default: ${FTPM_EC_EK_CERT})
	-p	The fTPM owner password. (Default: ${FTPM_OWNER_PW})
	-c	Keep certificate files after provisioning. (Optional)
	-d	Enable debug logs, show all logs. (Optional)
	-h	Shows this help.
EOM
}

function handle_null_ekb {
	log_error "fTPM provisioning failed because of EKB extraction failed."
	exit 1
}

function cleanup {
	log_debug "=== Cleaning up temporary files ==="

	# Remove temporary directory and its contents
	rm -rf ${FTPM_TEMP_OUT}

	# Remove EK certificate files if they exist and if not keeping certs
	if [ "${KEEP_CERTS}" = false ]; then
		if [ -f "${FTPM_RSA_EK_CERT}" ]; then
			log_debug "Removing RSA EK certificate and temp files"
			rm -rf "${FTPM_RSA_EK_CERT}"*
		fi

		if [ -f "${FTPM_EC_EK_CERT}" ]; then
			log_debug "Removing EC EK certificate and temp files"
			rm -rf "${FTPM_EC_EK_CERT}"*
		fi
	else
		log_debug "Keeping certificate files as requested"
		# Still remove temporary files but not the certificates
		rm -rf "${FTPM_RSA_EK_CERT}.*" 2>/dev/null || true
		rm -rf "${FTPM_EC_EK_CERT}.*" 2>/dev/null || true
	fi

	log_debug "Cleanup completed"
}

function ftpm_provisioning() {
	log_info "=== fTPM device provisioning ==="

	# Query device provisioning state
	log_debug "=== Query device provisioning state ==="
	ftpm_prov_st="$(${NV_FTPM_HELPER_APP} -i 2>&1 | grep "offline")"

	if [ -z "${ftpm_prov_st}" ]; then
		log_error "fTPM is not in correct provisioned state."
		# Return 0 to indicate that the provisioning failed
		# This will allow the service to continue
		exit 0
	fi

	# Check if tpm2 command exists
	if ! command -v tpm2_readpublic &> /dev/null; then
		log_error "tpm2-tools command not found. Please install tpm2-tools package."
		exit 1
	fi

	# Check if TPM device is ready to accept commands
	log_debug "=== Checking if TPM device is ready ==="
	max_attempts=10
	attempt=1
	tpm_ready=false

	while [ $attempt -le $max_attempts ]; do
		if tpm2_getcap -l &>/dev/null; then
			tpm_ready=true
			log_debug "TPM device is ready."
			break
		else
			log_debug "TPM device not ready, attempt $attempt of $max_attempts. Waiting..."
			sleep 0.5
			attempt=$((attempt + 1))
		fi
	done

	if [ "$tpm_ready" = false ]; then
		log_error "TPM device failed to become ready after $max_attempts attempts."
		exit 1
	fi

	# Check if EK already exists
	log_debug "=== Checking if EK already exists ==="
	if tpm2_readpublic -c ${RSA_EK_HANDLE} > /dev/null 2>&1 && \
	   tpm2_readpublic -c ${EC_EK_HANDLE} > /dev/null 2>&1; then
		log_debug "EK already exists."
		ek_exists=true
	else
		log_debug "EK does not exist, will create new ones."
		ek_exists=false
	fi

	# Check if EK certificates already in NV
	log_debug "=== Checking if EK certificates already in NV ==="
	if tpm2_nvread ${RSA_EK_CERT_HANDLE} > /dev/null 2>&1 && \
	   tpm2_nvread ${EC_EK_CERT_HANDLE} > /dev/null 2>&1; then
		log_debug "EK certificates already in NV."
		ek_cert_exists=true
	else
		log_debug "EK certificates not in NV, will write them."
		ek_cert_exists=false
	fi

	# If both EK and certificates exist, we can skip provisioning
	if [ "$ek_exists" = true ] && [ "$ek_cert_exists" = true ]; then
		log_info "TPM already fully provisioned. Skipping provisioning."
		return 0
	fi

	# Extract the EK certificates from EKB
	log_debug "=== Extracting the EK Certs from EKB ==="
	trap handle_null_ekb ERR
	${NV_FTPM_HELPER_APP} -a "${FTPM_RSA_EK_CERT}" -b "${FTPM_EC_EK_CERT}"

	# Extract the EK public keys from the certificates
	openssl x509 -inform DER -pubkey -noout -in "${FTPM_RSA_EK_CERT}" > "${FTPM_EKB_RSA_EK_PUB_KEY}"
	openssl x509 -inform DER -pubkey -noout -in "${FTPM_EC_EK_CERT}" > "${FTPM_EKB_EC_EK_PUB_KEY}"

	# Only clear TPM if we need to recreate EK
	if [ "$ek_exists" = false ]; then
		# Clean up fTPM
		log_debug "=== Clean up fTPM. ==="
		tpm2_clear

		# Take the ownership of the fTPM
		log_debug "=== Take the ownership of fTPM. ==="
		tpm2_changeauth -c o "${FTPM_OWNER_PW}"
		tpm2_changeauth -c e "${FTPM_OWNER_PW}"

		# Create EK
		tpm2_createek -c ${RSA_EK_HANDLE} -G rsa -w "${FTPM_OWNER_PW}" -P "${FTPM_OWNER_PW}" -f pem -u "${FTPM_RSA_EK_PUB_KEY}"
		tpm2_createek -c ${EC_EK_HANDLE} -G ecc -w "${FTPM_OWNER_PW}" -P "${FTPM_OWNER_PW}" -f pem -u "${FTPM_EC_EK_PUB_KEY}"

		# Validate the EK public keys
		log_debug "=== Validate the EK public keys. ==="
		_rsa_pubkey_diff="${FTPM_RSA_EK_PUB_KEY}.diff"
		_ec_pubkey_diff="${FTPM_EC_EK_PUB_KEY}.diff"
		diff ${FTPM_EKB_RSA_EK_PUB_KEY} ${FTPM_RSA_EK_PUB_KEY} > ${_rsa_pubkey_diff}; sync;
		diff ${FTPM_EKB_EC_EK_PUB_KEY} ${FTPM_EC_EK_PUB_KEY} > ${_ec_pubkey_diff}; sync;
		if [ -s ${_rsa_pubkey_diff} ] || [ -s ${_ec_pubkey_diff} ]; then
			log_error "The EK keys are invalid. Stop provisioning!!"
			exit 1
		fi
	fi

	# Only write certificates if they don't exist
	if [ "$ek_cert_exists" = false ]; then
		# Store the TPM EK certificate info fTPM NVMem
		log_debug "=== Store the EK certificates. ==="
		_rsa_ek_cert_size=$(wc -c < "${FTPM_RSA_EK_CERT}")
		tpm2_nvdefine ${RSA_EK_CERT_HANDLE} -C p -a ${EK_CERT_ATTR} -s "${_rsa_ek_cert_size}"
		tpm2_nvwrite ${RSA_EK_CERT_HANDLE} -C p -i "${FTPM_RSA_EK_CERT}"

		_ec_ek_cert_size=$(wc -c < "${FTPM_EC_EK_CERT}")
		tpm2_nvdefine ${EC_EK_CERT_HANDLE} -C p -a ${EK_CERT_ATTR} -s "${_ec_ek_cert_size}"
		tpm2_nvwrite ${EC_EK_CERT_HANDLE} -C p -i "${FTPM_EC_EK_CERT}"

		# Check the EK certificate in NV
		RSA_EK_CERT_IN_NV="${FTPM_RSA_EK_CERT}.ftpm_nv"
		EC_EK_CERT_IN_NV="${FTPM_EC_EK_CERT}.ftpm_nv"
		tpm2_nvread ${RSA_EK_CERT_HANDLE} -s "${_rsa_ek_cert_size}" -o "${RSA_EK_CERT_IN_NV}"
		tpm2_nvread ${EC_EK_CERT_HANDLE} -s "${_ec_ek_cert_size}" -o "${EC_EK_CERT_IN_NV}"

		_rsa_result="${RSA_EK_CERT_IN_NV}.diff"
		_ec_result="${EC_EK_CERT_IN_NV}.diff"
		diff "${FTPM_RSA_EK_CERT}" "${RSA_EK_CERT_IN_NV}" > "${_rsa_result}"; sync;
		diff "${FTPM_EC_EK_CERT}" "${EC_EK_CERT_IN_NV}" > "${_ec_result}"; sync;
		if [ -s "${_rsa_result}" ] || [ -s "${_ec_result}" ]; then
			log_error "EK certificate has not been written in NV!!"
			exit 1
		else
			log_info "EK certificate saved in NV successuflly."
		fi
	fi

	# Empty separator line - only if we're showing debug output
	log_debug ""
}

function remove_tpm_password() {
	log_debug "=== Removing TPM owner and endorsement passwords ==="

	# Try to remove owner password with current password
	if tpm2_changeauth -c o "" -p "${FTPM_OWNER_PW}" 2>/dev/null; then
		log_debug "TPM owner password removed successfully."
	else
		# Try without password (in case it's already blank)
		if tpm2_changeauth -c o "" 2>/dev/null; then
			log_debug "TPM owner password removed successfully."
		else
			log_error "Failed to remove TPM owner password."
		fi
	fi

	# Try to remove endorsement password with current password
	if tpm2_changeauth -c e "" -p "${FTPM_OWNER_PW}" 2>/dev/null; then
		log_debug "TPM endorsement password removed successfully."
	else
		# Try without password (in case it's already blank)
		if tpm2_changeauth -c e "" 2>/dev/null; then
			log_debug "TPM endorsement password removed successfully."
		else
			log_error "Failed to remove TPM endorsement password."
		fi
	fi
}

trap cleanup EXIT

# Don't exit if no parameters - use defaults instead
if [ $# -eq 0 ]; then
    log_debug "No parameters provided, using defaults"
else
	# Continue with default values
    while getopts "hr:e:p:cd" OPTION
    do
        case $OPTION in
            h)
                usage
                exit 0
            ;;
            r)
                FTPM_RSA_EK_CERT="${OPTARG}"
            ;;
            e)
                FTPM_EC_EK_CERT="${OPTARG}"
            ;;
            p)
                FTPM_OWNER_PW="${OPTARG}"
            ;;
            c)
                KEEP_CERTS=true
            ;;
            d)
                # Set log level to show all logs
                LOG_LEVEL=${LOG_DEBUG}
                log_info "Debug mode enabled. Showing all logs."
            ;;
            *)
                usage
                exit 1
            ;;
        esac
    done
fi

mkdir -p ${FTPM_TEMP_OUT}
ftpm_provisioning
remove_tpm_password
