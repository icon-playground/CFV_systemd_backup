#!/bin/bash

#
# SPDX-FileCopyrightText: Copyright (c) 2019-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
# list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its
# contributors may be used to endorse or promote products derived from
# this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

if [ ! -e /etc/nv/nvfirstboot ]; then
	exit 0
fi

function wait_debconf_resource() {
	# Wait for the process to finish which has aquired this lock
	while fuser "/var/cache/debconf/config.dat" > "/dev/null" 2>&1; do sleep 1; done;
	while fuser "/var/cache/debconf/templates.dat" > "/dev/null" 2>&1; do sleep 1; done;
}

update-alternatives \
	--install /etc/ld.so.conf.d/aarch64-linux-gnu_EGL.conf \
	aarch64-linux-gnu_egl_conf \
	/usr/lib/aarch64-linux-gnu/tegra-egl/ld.so.conf 1000
update-alternatives \
	--install /etc/ld.so.conf.d/aarch64-linux-gnu_GL.conf \
	aarch64-linux-gnu_gl_conf \
	/usr/lib/aarch64-linux-gnu/nvidia/ld.so.conf 1000

update-alternatives \
	--install /usr/sbin/iptables iptables /usr/sbin/iptables-legacy 1000 \
	--slave /usr/sbin/iptables-restore iptables-restore /usr/sbin/iptables-legacy-restore \
	--slave /usr/sbin/iptables-save iptables-save /usr/sbin/iptables-legacy-save
update-alternatives \
	--install /usr/sbin/ip6tables ip6tables /usr/sbin/ip6tables-legacy 1000 \
	--slave /usr/sbin/ip6tables-restore ip6tables-restore /usr/sbin/ip6tables-legacy-restore \
	--slave /usr/sbin/ip6tables-save ip6tables-save /usr/sbin/ip6tables-legacy-save

if [ ! -e "/usr/bin/python" ] && [ ! -e "/etc/alternatives/python" ]; then
	if [ -e "/usr/bin/python2" ]; then
		update-alternatives --install /usr/bin/python python /usr/bin/python2 1000
	elif [ -e "/usr/bin/python3" ]; then
		update-alternatives --install /usr/bin/python python /usr/bin/python3 1000
	fi
fi


NV_INTERNAL_SCRIPT="/usr/bin/nv_internal_target.sh"

if [ -f "${NV_INTERNAL_SCRIPT}" ]; then
	"${NV_INTERNAL_SCRIPT}" --t2c-tracking-ldconfig-pause
fi

ldconfig

if [ -f "${NV_INTERNAL_SCRIPT}" ]; then
	"${NV_INTERNAL_SCRIPT}" --t2c-tracking-ldconfig-resume
fi

# Read total memory size in megabyte
if TOTAL_MEM=$(free --mega | awk '/^Mem:/{print $2}'); then
	TOTAL_MEM=$(echo "scale=1;${TOTAL_MEM}/1000" | bc)
	TOTAL_MEM=$(echo "${TOTAL_MEM}" | awk '{print int($1+0.5)}')

	# If RAM size is less than 4 GB, set default display manager as LightDM
	if [ -e "/lib/systemd/system/lightdm.service" ] &&
		[ "${TOTAL_MEM}" -lt 4 ]; then
		DEFAULT_DM=$(cat "/etc/X11/default-display-manager")
		if [ "${DEFAULT_DM}" != "/usr/sbin/lightdm" ]; then
			echo "/usr/sbin/lightdm" > "/etc/X11/default-display-manager"
			wait_debconf_resource
			DEBIAN_FRONTEND=noninteractive DEBCONF_NONINTERACTIVE_SEEN=true dpkg-reconfigure lightdm
			echo set shared/default-x-display-manager lightdm | debconf-communicate
		fi
	fi
else
	echo "ERROR: Cannot get total memory size."
fi

# Allow anybody to run X
if [ -f "/etc/X11/Xwrapper.config" ]; then
	sed -i 's/allowed_users.*/allowed_users=anybody/' "/etc/X11/Xwrapper.config"
	echo "needs_root_rights=yes" >> "/etc/X11/Xwrapper.config"
fi

# To get profiles from pulseaudio rather than UCM for HDA card
if [ -e "/usr/share/alsa/ucm2/Tegra/tegra-hda/tegra-hda.conf" ]; then
	unlink /usr/share/alsa/ucm2/conf.d/tegra-hda/tegra-hda.conf
	rm -f /usr/share/alsa/ucm2/Tegra/tegra-hda/tegra-hda.conf
fi
