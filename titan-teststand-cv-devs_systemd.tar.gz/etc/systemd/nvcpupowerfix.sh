#!/bin/bash

# SPDX-FileCopyrightText: Copyright (c) 2023 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

if grep -q "nvidia,tegra234" "/proc/device-tree/compatible"; then
    for policy in /sys/devices/system/cpu/cpufreq/policy*; do
        # Turn on/off the first CPU if all CPUs in that cluster are offline
        if [[ -f "${policy}/affected_cpus" && -z $(cat "${policy}/affected_cpus") ]]; then
            cpu_n=$(awk '{ print $1 }' "${policy}/related_cpus")
            if [[ "${cpu_n}" =~ ^[0-9]+$ ]]; then
                echo 1 > "/sys/devices/system/cpu/cpu${cpu_n}/online"
                echo 0 > "/sys/devices/system/cpu/cpu${cpu_n}/online"
            fi
        fi
    done
fi