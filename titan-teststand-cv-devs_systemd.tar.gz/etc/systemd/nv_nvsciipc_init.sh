#!/bin/bash
# SPDX-FileCopyrightText: Copyright (c) 2021-2023 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

#
# nvsciipc_init - NvSciIpc Init service
#

NVSCIIPC_DEVNODE="/dev/nvsciipc"
FILE="$(basename -- "$0")"

if [ ! -c "${NVSCIIPC_DEVNODE}" ]
then
	echo "${FILE}[$$]: no ${NVSCIIPC_DEVNODE}" > /dev/kmsg
	logger -i "${FILE}: no ${NVSCIIPC_DEVNODE}"
	exit 0
else
	echo "${FILE}[$$]: found ${NVSCIIPC_DEVNODE}" > /dev/kmsg
	logger -i "${FILE}: found ${NVSCIIPC_DEVNODE}"

	# TODO: update device node security
	chmod 666 "${NVSCIIPC_DEVNODE}"
fi

NVSCIIPC_INIT_EXEC="/usr/bin/nvsciipc_init"

if [ -f "${NVSCIIPC_INIT_EXEC}" ]
then
	${NVSCIIPC_INIT_EXEC}
fi

